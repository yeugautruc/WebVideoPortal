# VideoPortal

VideoPortal is a website from our project in subject: WebProgrammierung in our uni.

## Installation

Load this website into any Web-server. Run index.html to experience the website.

## Usage

Use one of those user data to login portal:
```javascript
[{
    "username": "user1",
    "password": 123
}, {
    "username": "user2",
    "password": 1234
}, {
    "username": "user3",
    "password": 12345
}]
```
## History diary

Feel free to visit our github project or trello record to see our program diary and project UML.

[Github](https://github.com/yeugautruc/WebVideoPortal)

[Trello](https://trello.com/b/CYNjCcU5/web-programmierung-ss20-group36)

## Contributing

If have any issues please contact us on m.doan@ostfalia.

Or use contact form directly in our website.

## Author

Group 36

## License

Contents of project are used only for education purpose.

Free Images from [Unsplash](https://unsplash.com)

Video sources from [Youtube](https://youtube.com)

Font sources from [Google Fonts](https://fonts.google.com/)
